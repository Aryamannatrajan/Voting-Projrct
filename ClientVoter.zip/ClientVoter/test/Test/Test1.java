/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package Test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.StringTokenizer;

/**
 *
 * @author abhimanyuyadav
 */
public class Test1 {

    public static void main(String args[]) {
        String gender;
        String part;
        try {
            String urL = "jdbc:mysql://localhost:3306/TBS?zeroDateTimeBehavior=CONVERT_TO_NULL";
            String user = "root";
            String pass = "TBS@admin123";
            Connection conn = DriverManager.getConnection(urL, user, pass);

            Statement st = conn.createStatement();
            String q1 = "SELECT * FROM COMMAND";
            ResultSet rs = st.executeQuery(q1);

            while (rs.next()) {

                int check = rs.getInt("com");

                //  command = false;
                part = rs.getNString("PART");
                StringTokenizer stt = new StringTokenizer(part, ":");
                part = stt.nextToken();
                gender = stt.nextToken();
                System.out.println(part + "\t" + gender);

            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
