/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clientvoter;

import java.sql.*;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author abhimanyuyadav
 */
public class WaitAndConfirmSr implements Runnable {

    ClFrame2 cl2;
    String gender;
    String ipkey;
    int id;
    int ctr;

    public WaitAndConfirmSr(ClFrame2 cl2, String ipkey, int id) {
        this.cl2 = cl2;
        gender = "";
        this.ipkey = ipkey;
        this.id = id;
        ctr = 0;
    }

    @Override
    public void run() {

        if (id == 14) {
            new Complete().setVisible(true);
            cl2.setVisible(false);
        } else {
            boolean command = true;
            String part = "";
            try {
                String urL = "jdbc:mysql://localhost:3306/TBS?zeroDateTimeBehavior=CONVERT_TO_NULL";
                String user = "root";
                String pass = "TBS@admin123";
                Connection conn = DriverManager.getConnection(urL, user, pass);

                while (command) {
                    Statement st = conn.createStatement();
                    String q1 = "SELECT * FROM COMMANDSR";
                    ResultSet rs = st.executeQuery(q1);

                    while (rs.next()) {

                        if (rs.getBoolean("com") && (rs.getInt("ID") == id)) {
                            command = false;
                            part = rs.getNString("PART");
                            StringTokenizer stt = new StringTokenizer(part, ":");
                            part = stt.nextToken();
                            gender = stt.nextToken();
                            break;
                        }

                    }
                }

                System.out.println(part);
                GETANDSEND_DATA ob = new GETANDSEND_DATA(cl2, part, gender, ipkey, id, true);

            } catch (SQLException ex) {
                Logger.getLogger(WaitAndConfirm.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    public static void main(String args[]) {

    }

}
