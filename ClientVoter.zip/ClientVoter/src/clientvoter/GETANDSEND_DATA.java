/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clientvoter;

import java.awt.Image;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.sql.*;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;

/**
 *
 * @author abhimanyuyadav
 */
public class GETANDSEND_DATA {

    ArrayList<String> candidateName;
    ArrayList<Image> candidatePhoto;
    ArrayList<String> candidateHouse;
    ArrayList<Integer> candidateCode;
    ClFrame2 clframe2;
    String part = "";
    String gender = "";
    String ipkey;
    int id;
    boolean isSrSchool;

    public GETANDSEND_DATA(ClFrame2 clframe2, String part, String gender, String ipkey, int id, boolean isSrSchool) {

        candidateName = new ArrayList<>();
        candidatePhoto = new ArrayList<>();
        candidateHouse = new ArrayList<>();
        candidateCode = new ArrayList<>();
        this.clframe2 = clframe2;
        this.part = part;
        this.gender = gender;
        this.ipkey = ipkey;
        this.id = id;
        // System.out.println(part);

        this.isSrSchool = isSrSchool;
        if (isSrSchool) {
            getData();
        } else {
            getData2();
        }

    }

    private void sendData(ClFrame2 clframe2) {
        //  System.out.println("Reached sendData");
        int a = candidateName.size();
        //   System.out.println(part);
        new ClFrame3(a, candidateName, candidateHouse, candidatePhoto, part, gender, candidateCode, ipkey, id, isSrSchool).setVisible(true);
        clframe2.setVisible(false);
    }

    private void getData() {
        System.out.println("Reached getData");
        try {
            String url = "jdbc:mysql://localhost:3306/TBS?zeroDateTimeBehavior=CONVERT_TO_NULL";
            String user = "root";
            String pass = "TBS@admin123";

            //  DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
            Connection conn = DriverManager.getConnection(url, user, pass);
            Statement st = conn.createStatement();
            String q1 = "SELECT * FROM CANDIDATE";
            ResultSet rs = st.executeQuery(q1);
            String name = "";
            String house = "";
            Image photo;
            InputStream is;
            while (rs.next()) {

                String position = rs.getString("POSITION");
                StringTokenizer stt = new StringTokenizer(position, " ");
                String sub1 = stt.nextToken();
                String sub2 = sub1 + " HOUSE VICE CAPTAIN";
                if (part.equals(position) || (part.equals(sub2) && !position.contains("MONITORS"))) {
                    
                    name = rs.getNString("NAME");
                    house = rs.getNString("HOUSE");
                    Blob blob = rs.getBlob("PHOTO");
                    int comp_code = rs.getInt("CODE");
                    is = blob.getBinaryStream();
                    photo = ImageIO.read(is);
                    candidateName.add(name);
                    candidateHouse.add(house);
                    candidatePhoto.add(photo);
                    candidateCode.add(comp_code);
                }

            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            Logger.getLogger(GETANDSEND_DATA.class.getName()).log(Level.SEVERE, null, ex);
        }
        sendData(clframe2);
    }

    private void getData2() {
        try {
            String url = "jdbc:mysql://localhost:3306/TBS?zeroDateTimeBehavior=CONVERT_TO_NULL";
            String user = "root";
            String pass = "TBS@admin123";

            Connection conn = DriverManager.getConnection(url, user, pass);
            Statement st = conn.createStatement();
            String q1 = "SELECT * FROM CANDIDATE_" + gender;
            ResultSet rs = st.executeQuery(q1);
            String name;
            String house;
            Image photo;
            InputStream is;

            while (rs.next()) {
                String position = rs.getString("POSITION");
                StringTokenizer stt = new StringTokenizer(position, " ");
                String sub1 = stt.nextToken();
                String sub2 = sub1 + " HOUSE VICE CAPTAIN";
                sub1 = sub1 + " HOUSE CAPTAIN";
                System.out.println(part + "\t" + sub1 + "\t" + sub2);
                if (position.equalsIgnoreCase(part) || part.equals(sub1) || part.equals(sub2)) {
                    name = rs.getNString("NAME");
                    house = rs.getNString("HOUSE");
                    Blob blob = rs.getBlob("PHOTO");
                    int comp_code = rs.getInt("CODE");
                    is = blob.getBinaryStream();
                    photo = ImageIO.read(is);
                    candidateName.add(name);
                    candidateHouse.add(house);
                    candidatePhoto.add(photo);
                    candidateCode.add(comp_code);
                }
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            Logger.getLogger(GETANDSEND_DATA.class.getName()).log(Level.SEVERE, null, ex);
        }
        sendData(clframe2);
    }
}
