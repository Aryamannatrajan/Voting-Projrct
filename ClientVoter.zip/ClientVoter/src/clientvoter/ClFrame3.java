/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clientvoter;

import java.sql.*;
import java.awt.AlphaComposite;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JViewport;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

/**
 *
 * @author abhimanyuyadav
 * @author dhirodaattosarkar // Designed the card UI
 */
public class ClFrame3 extends javax.swing.JFrame {

    ArrayList<JPanel> candidate;
    ArrayList<JLabel> candidateImage;
    ArrayList<JLabel> candidateName;
    ArrayList<JLabel> candidateHouse;
    ArrayList<JButton> candidateSelection;
    ArrayList<JButton> candidateSelection2;
    ArrayList<Boolean> isSelected;
    ArrayList<Boolean> isSelectedMon;

    ArrayList<String> name;
    ArrayList<String> house;
    ArrayList<Image> photo;
    ArrayList<ImageIcon> icons;
    ArrayList<Integer> comp_code;

    int prefectSelected[];
    int monitorsSelected[] = new int[2];

    String part;
    int x = 0;
    int width;
    String gender;
    String ipkey;
    int id;
    ClFrame3 cl3;
    int sctr =0;
    int pno;
    boolean isSrSchool;

    public ClFrame3() {

        initDisplayElements();
        initComponents();

    }

    public ClFrame3(int a, ArrayList<String> name, ArrayList<String> house, ArrayList<Image> photo, String part, String gender, ArrayList<Integer> comp_code, String ipkey, int id, boolean isSrSchool) {

        // Initialising Display Elements
        getNoPre();
        this.isSrSchool = isSrSchool;
        isSelected = new ArrayList<>();
        isSelectedMon = new ArrayList<>();
        init(name.size());
        prefectSelected = new int[pno];
        initDisplayElements();

        sctr = 0;
        //Initialising the values received
        this.name = name;
        this.house = house;
        this.photo = photo;
        this.gender = gender;
        icons = new ArrayList<>();

        this.comp_code = comp_code;
        this.ipkey = ipkey;
        System.out.println(name.size());
        this.part = "CANDIDATES FOR " + part;

        x = a;
        initComponents();
        partName.setText(this.part);
        width = jPanel5.getWidth();
        cl3 = this;
        this.id = id;

    }

    private void init(int n) {
        for (int i = 0; i < n; i++) {
            isSelected.add(false);
            isSelectedMon.add(false);
        }
    }

    private void getNoPre() {
        try {
            String urL = "jdbc:mysql://localhost:3306/TBS?zeroDateTimeBehavior=CONVERT_TO_NULL";
            String user = "root";
            String pass = "TBS@admin123";
            Connection conn = DriverManager.getConnection(urL, user, pass);
            Statement st = conn.createStatement();
            String q = "SELECT * FROM tbs.PrefectsNo";
            ResultSet rs = st.executeQuery(q);
            while (rs.next()) {
                pno = rs.getInt("PNO");
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    MouseListener ml = new MouseListener() {
        @Override
        public void mouseClicked(MouseEvent e) {

            for (int i = 0; i < candidate.size(); i++) {
                if (e.getSource() == candidate.get(i)) {
                    candidate.get(i).setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(47, 101, 202), 3));
                    for (int j = 0; j < candidate.size(); j++) {
                        if (!(j == i)) {
                            candidate.get(i).setBorder(null);
                        }

                    }
                } else if (part.contains("PREFECTS")) {
                    if (!isSelected.get(i)) {
                        candidate.get(i).setBorder(null);
                    } else {
                        candidate.get(i).setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(47, 101, 202), 3));
                    }
                } else if (part.contains("MONITORS")) {
                    if (!isSelectedMon.get(i)) {
                        candidate.get(i).setBorder(null);
                    } else {
                        candidate.get(i).setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(47, 101, 202), 3));
                    }
                }

            }
        }

        @Override
        public void mousePressed(MouseEvent e) {

            for (int i = 0; i < candidate.size(); i++) {
                if (e.getSource() == candidate.get(i)) {
                    candidate.get(i).setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(47, 101, 202), 3));
                    for (int j = 0; j < candidate.size(); j++) {
                        if (!(j == i)) {
                            candidate.get(i).setBorder(null);
                        }

                    }
                } else if (part.contains("PREFECTS")) {
                    if (!isSelected.get(i)) {
                        candidate.get(i).setBorder(null);
                    } else {
                        candidate.get(i).setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(47, 101, 202), 3));
                    }
                } else if (part.contains("MONITORS")) {
                    if (!isSelectedMon.get(i)) {
                        candidate.get(i).setBorder(null);
                    } else {
                        candidate.get(i).setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(47, 101, 202), 3));
                    }
                }

            }

        }

        @Override
        public void mouseReleased(MouseEvent e) {

            for (int i = 0; i < candidate.size(); i++) {
                if (e.getSource() == candidate.get(i)) {
                    candidate.get(i).setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(47, 101, 202), 3));
                    for (int j = 0; j < candidate.size(); j++) {
                        if (!(j == i)) {
                            candidate.get(i).setBorder(null);
                        }

                    }
                } else if (part.contains("PREFECTS")) {
                    if (!isSelected.get(i)) {
                        candidate.get(i).setBorder(null);
                    } else {
                        candidate.get(i).setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(47, 101, 202), 3));
                    }
                } else if (part.contains("MONITORS")) {
                    if (!isSelectedMon.get(i)) {
                        candidate.get(i).setBorder(null);
                    } else {
                        candidate.get(i).setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(47, 101, 202), 3));
                    }
                }

            }
            //    throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        @Override
        public void mouseEntered(MouseEvent e) {
            for (int i = 0; i < candidate.size(); i++) {
                if (e.getSource() == candidate.get(i)) {
                    candidate.get(i).setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(47, 101, 202), 3));

                } else if (part.contains("PREFECTS")) {
                    if (!isSelected.get(i)) {
                        candidate.get(i).setBorder(null);
                    } else {
                        candidate.get(i).setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(47, 101, 202), 3));
                    }
                } else if (part.contains("MONITORS")) {
                    if (!isSelectedMon.get(i)) {
                        candidate.get(i).setBorder(null);
                    } else {
                        candidate.get(i).setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(47, 101, 202), 3));
                    }
                }

            }
            //    throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        @Override
        public void mouseExited(MouseEvent e) {

            for (int i = 0; i < candidate.size(); i++) {
                if (e.getSource() == candidate.get(i)) {
                    candidate.get(i).setBorder(null);

                } else if (part.contains("PREFECTS")) {
                    if (!isSelected.get(i)) {
                        candidate.get(i).setBorder(null);
                    } else {
                        candidate.get(i).setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(47, 101, 202), 3));
                    }
                } else if (part.contains("MONITORS")) {
                    if (!isSelectedMon.get(i)) {
                        candidate.get(i).setBorder(null);
                    } else {
                        candidate.get(i).setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(47, 101, 202), 3));
                    }
                }

            }

        }

    };

    private void initDisplayElements() {
        this.candidate = new ArrayList<>();
        this.candidateImage = new ArrayList<>();
        this.candidateName = new ArrayList<>();
        this.candidateHouse = new ArrayList<>();
        this.candidateSelection = new ArrayList<>();
        this.candidateSelection2 = new ArrayList<>();
    }

    private void displayer(int n) // private void displayer(int n, ArrayList<String> name)
    {
        for (int i = 0; i < n; i++) {
            // Name.add(name.get(i));   
            groupInitialiser(i, photo.get(i), name.get(i), house.get(i));

        }
        for (int i = 0; i < n; i++) {
            groupDisplayer(i);
        }
    }

    private void groupInitialiser(int i, Image photo, String name, String house) // private void masterInitialiser(int i, Image img, String nam, String house)
    {
        candidate.add(initialisePanel(i));
        candidateImage.add(initialiseImage(photo, i));
        candidateName.add(initialiseName(name));
        candidateHouse.add(initialiseHouse(house));
        candidateSelection.add(initialiseSelection());
        candidateSelection2.add(initialiseSelection2());

    }

    private void groupDisplayer(int i) {
        displayPanel(candidate.get(i));
        displayImage(candidateImage.get(i), i);
        displayName(i);
        displayHouse(i);
        displaySelection(i);
        displaySelection2(i);
    }

    // initializes a single panel with spacing and returns it.
    private JPanel initialisePanel(int i) {
        int fields = (width - 70) / 2;
        int f = i % fields;

        int j = i;
        double i1 = i;
        j = i % 6;

        double yValD = Math.floor(i1 / 6.0);
        int yVal = (int) yValD;
        JPanel panel = new JPanel();

        panel.setBounds(35 + (j * 224), 115 + 245 * yVal, 224, 245);

        //panel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        javax.swing.GroupLayout Panel = new javax.swing.GroupLayout(panel);
        panel.setLayout(Panel);
        panel.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        panel.addMouseListener(ml);

        return panel;
    }

    private JLabel initialiseImage(Image photo, int i) {

        JLabel jl = new JLabel();
        jl.setBounds(36, 12, 150, 150);
        jl.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jl.setSize(150, 150);
        photo = resizeImage(photo, 150, 150);
        ImageIcon icon = new ImageIcon(photo);
        jl.setIcon(icon);
        photo = resizeImage(photo, 100, 100);
        icon = new ImageIcon(photo);
        icons.add(i, icon);
        jl.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        return jl;
    }

    private JLabel initialiseName(String name) {
        JLabel jl = new JLabel();
        jl.setBounds(0, 170, 224, 23);
        jl.setFont(new java.awt.Font("Helvetica Neue", 0, 14)); // NOI18N
        jl.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        // if(s.length()>22) -> {jl.setFont(new java.awt.Font("Helvetica Neue", 0, 12));}
        jl.setText(name);
        jl.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        return jl;
    }

    private JLabel initialiseHouse(String house) {
        JLabel jl = new JLabel();
        jl.setBounds(36, 199, 150, 20);
        jl.setFont(new java.awt.Font("Helvetica Neue", 0, 14));
        jl.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jl.setText(house);
        jl.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        return jl;
    }

    private JButton initialiseSelection() {
        JButton jb = new JButton();
        jb.setBounds(90, 218, 50, 20);
        jb.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jb.setText("Vote");
        jb.addActionListener(al);

        return jb;
    }

    private JButton initialiseSelection2() {
        JButton jb = new JButton();
        jb.setBounds(70, 218, 100, 20);
        jb.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jb.setText("Undo Selection");
        jb.addActionListener(al2);

        return jb;
    }

    private void displayPanel(JPanel panel) {
        jPanel5.add(panel);
        panel.setVisible(true);
    }

    private void displayImage(JLabel jl, int i) {
        candidate.get(i).add(jl);
        jl.setVisible(true);
    }

    private void displayName(int i) {
        candidate.get(i).add(candidateName.get(i));
        candidateName.get(i).setVisible(true);
    }

    private void displayHouse(int i) {
        candidate.get(i).add(candidateHouse.get(i));
        candidateHouse.get(i).setVisible(true);
    }

    private void displaySelection(int i) {
        candidate.get(i).add(candidateSelection.get(i));
        candidateSelection.get(i).setVisible(true);
    }

    private void displaySelection2(int i) {
        candidate.get(i).add(candidateSelection2.get(i));
        candidateSelection2.get(i).setVisible(false);
    }

    public static BufferedImage resizeImage(final Image image, int width, int height) {
        final BufferedImage bufferedImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        final Graphics2D graphics2D = bufferedImage.createGraphics();
        graphics2D.setComposite(AlphaComposite.Src);
        //below three lines are for RenderingHints for better image quality at cost of higher processing time
        graphics2D.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        graphics2D.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        graphics2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        graphics2D.drawImage(image, 0, 0, width, height, null);
        graphics2D.dispose();
        return bufferedImage;
    }

    ActionListener al = new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            candidateSelection.stream().filter((jb) -> (e.getSource() == jb)).forEachOrdered((jb) -> {
                for (int i = 0; i < candidateSelection.size(); i++) {
                    if (candidateSelection.get(i) == jb) {

                        if (!part.contains("PREFECTS") && !part.contains("MONITORS")) {
                            int response = JOptionPane.showConfirmDialog(null, "Submit Vote for: \n" + name.get(i) + "\n" + house.get(i), "Confirm Vote", JOptionPane.OK_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, icons.get(i));
                            if (response == JOptionPane.OK_OPTION) {

                                ClFrame2 cl2 = new ClFrame2();
                                cl2.setVisible(true);
                                if (!isSrSchool) {
                                    Thread t = new Thread(new castVote(gender, comp_code.get(i)));
                                    t.start();
                                    Thread t2 = new Thread(new WaitAndConfirm(cl2, ipkey, ++id));
                                    t2.start();
                                    Thread t3 = new Thread(new sendVote2(ipkey));
                                    t3.start();
                                } else {
                                    Thread t = new Thread(new castVoteSr(gender, comp_code.get(i)));
                                    t.start();
                                    Thread t2 = new Thread(new WaitAndConfirmSr(cl2, ipkey, ++id));
                                    t2.start();
                                    Thread t3 = new Thread(new sendVote2(ipkey));
                                    t3.start();
                                }
                                cl3.setVisible(false);
                            }
                        } else if (part.contains("PREFECTS")) {
                            if (sctr < pno - 1) {
                                
                                isSelected.set(i, true);
                                candidateSelection.get(i).setVisible(false);
                                candidateSelection2.get(i).setVisible(true);
                                prefectSelected[sctr] = comp_code.get(i);
                                sctr++;
                            } else  {

                                
                                isSelected.set(i, true);
                                candidate.get(i).setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(47, 101, 202), 3));
                                candidateSelection.get(i).setVisible(false);
                                candidateSelection2.get(i).setVisible(true);
                                prefectSelected[sctr] = comp_code.get(i);
                                sctr++;
                                int response = JOptionPane.showConfirmDialog(null, "Confirm your (" + pno + ") selections", "Confirm Selection?", JOptionPane.OK_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE);
                                if (response == JOptionPane.OK_OPTION) {

                                    ClFrame2 cl2 = new ClFrame2();
                                    cl2.setVisible(true);
                                    if (!isSrSchool) {
                                        Thread t = new Thread(new castVotePre(gender, prefectSelected, pno));
                                        t.start();
                                        Thread t2 = new Thread(new WaitAndConfirm(cl2, ipkey, ++id));
                                        t2.start();
                                        Thread t3 = new Thread(new sendVote2(ipkey));
                                        t3.start();
                                    } else {
                                        Thread t = new Thread(new castVotePreSr(gender, prefectSelected, pno));
                                        t.start();
                                        Thread t2 = new Thread(new WaitAndConfirmSr(cl2, ipkey, ++id));
                                        t2.start();
                                        Thread t3 = new Thread(new sendVote2(ipkey));
                                        t3.start();
                                    }
                                    cl3.setVisible(false);
                                }
                            }
                        } else {
                            if (sctr < 1) {
                                
                                isSelectedMon.set(i, true);
                                candidate.get(i).setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(47, 101, 202), 3));
                                candidateSelection.get(i).setVisible(false);
                                candidateSelection2.get(i).setVisible(true);
                                monitorsSelected[sctr] = comp_code.get(i);
                                System.out.println(monitorsSelected[sctr]);
                                sctr++;
                            } else {

                                candidate.get(i).setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(47, 101, 202), 3));
                                isSelectedMon.set(i, true);
                                candidateSelection.get(i).setVisible(false);
                                candidateSelection2.get(i).setVisible(true);
                                monitorsSelected[sctr] = comp_code.get(i);
                                sctr++;
                                int response = JOptionPane.showConfirmDialog(null, "Confirm your (" + pno + ") selections", "Confirm Selection?", JOptionPane.OK_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE);
                                if (response == JOptionPane.OK_OPTION) {

                                    ClFrame2 cl2 = new ClFrame2();
                                    cl2.setVisible(true);
                                    Thread t = new Thread(new castVotePreSr(gender, monitorsSelected, 2));
                                    t.start();
                                    Thread t2 = new Thread(new WaitAndConfirmSr(cl2, ipkey, ++id));
                                    t2.start();
                                    Thread t3 = new Thread(new sendVote2(ipkey));
                                    t3.start();

                                    cl3.setVisible(false);
                                }
                            }
                        }

                    }
                }
            });
        }

    };

    ActionListener al2 = new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {

            for (int i = 0; i < candidate.size(); i++) {
                if (e.getSource() == candidateSelection2.get(i)) {
                    sctr--;
                    candidate.get(i).setBorder(null);
                    isSelected.set(i, false);
                    candidateSelection.get(i).setVisible(true);
                    candidateSelection2.get(i).setVisible(false);
                    prefectSelected[i] = 0;

                }
            }
        }

    };

    /**
     * Creates new form ClFrame3
     */
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        filler1 = new javax.swing.Box.Filler(new java.awt.Dimension(0, 0), new java.awt.Dimension(0, 0), new java.awt.Dimension(32767, 32767));
        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        filler2 = new javax.swing.Box.Filler(new java.awt.Dimension(0, 0), new java.awt.Dimension(0, 0), new java.awt.Dimension(32767, 32767));
        jScrollPane2 = new javax.swing.JScrollPane();
        jPanel5 = new javax.swing.JPanel();
        partName = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(163, 29, 36));

        jPanel3.setBackground(new java.awt.Color(163, 29, 36));

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 48)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 204, 51));
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/clientvoter/BLogo1 (1).png"))); // NOI18N
        jLabel1.setText("                 THE BISHOP'S SCHOOL,PUNE");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 1792, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(filler2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(filler2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap(1840, Short.MAX_VALUE)
                .addComponent(filler1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel2Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addContainerGap()))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(101, Short.MAX_VALUE)
                .addComponent(filler1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29))
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel2Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );

        jScrollPane2.setBorder(null);
        jScrollPane2.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane2.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        jScrollPane2.getVerticalScrollBar().setUnitIncrement(7);
        jScrollPane2.getViewport ().setScrollMode ( JViewport.BACKINGSTORE_SCROLL_MODE );

        displayer(x);

        partName.setFont(new java.awt.Font("Helvetica", 1, 36)); // NOI18N
        partName.setForeground(new java.awt.Color(102, 102, 102));
        partName.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        partName.setText("CANDIDATES FOR HEAD BOY");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(partName, javax.swing.GroupLayout.DEFAULT_SIZE, 1418, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addComponent(partName, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(1033, Short.MAX_VALUE))
        );

        jScrollPane2.setViewportView(jPanel5);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 1433, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 1440, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ClFrame3.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        try {
            //</editor-fold>
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException ex) {
            Logger.getLogger(ClFrame3.class.getName()).log(Level.SEVERE, null, ex);
        }
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new ClFrame3().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.Box.Filler filler1;
    private javax.swing.Box.Filler filler2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel partName;
    // End of variables declaration//GEN-END:variables
}
