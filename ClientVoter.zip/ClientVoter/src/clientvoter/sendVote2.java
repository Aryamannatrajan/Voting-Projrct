/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package clientvoter;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;

/**
 *
 * @author abhimanyuyadav
 */
public class sendVote2 implements Runnable {
     String ip = "";
     int d;
    public sendVote2(String ip1)
    {
        ip = ip1;
        d= -1;
    }
    public static void main(String args[])
    {
        
    }

    /**
     *
     */
  

    @Override
    public void run() {
        Socket s = null;
        
        try {
            s = new Socket(ip,7070);
        } catch (IOException ex) {
            System.out.println("Error with socket connection");
        }
        try
        {
            DataInputStream dis = new DataInputStream(s.getInputStream());
            String x = dis.readUTF();
            DataOutputStream dout = new DataOutputStream(s.getOutputStream());
            System.out.println(x);
            d=1;
            Thread.sleep(2000);
            dout.writeInt(d);
            
            s.close();
            System.out.println("Connection closed successfully");
        }
        catch(Exception e)
        {
            System.out.println("Error in during excecution");
        }
    }
}
