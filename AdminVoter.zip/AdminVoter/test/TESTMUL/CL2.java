/*
 * Copyright (C) 2020 abhimanyuyadav
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
package TESTMUL;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;

/**
 *
 * @author abhimanyuyadav
 */
public class CL2 {
    
    public static void main(String args[])
    {
        
        CL2 ob = new CL2();
                ob.implement();
    }
    public void implement()
    {
        //String name = b;
       // System.out.println(b);
        String ip = null;
        try
        {
            ip = Ip.IP();
        }
        catch(Exception e)
        {
            System.out.println("Error getting ip");
        }
        Socket s = null;
        
        try {
            s = new Socket(ip,8080);
        } catch (IOException ex) {
            System.out.println("Error with socket connection");
        }
        try
        {
            DataInputStream dis = new DataInputStream(s.getInputStream());
            String x = dis.readUTF();
            DataOutputStream dout = new DataOutputStream(s.getOutputStream());
            System.out.println(x);
            int a = -1;
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            System.out.println("Enter data ");
            String d = br.readLine();
            a = Integer.valueOf(d);
            dout.writeInt(a);
            
            s.close();
            System.out.println("Connection closed successfully");
        }
        catch(Exception e)
        {
            System.out.println("Error in during excecution");
        }
    }
}
