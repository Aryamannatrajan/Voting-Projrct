/*
 * Copyright (C) 2020 abhimanyuyadav
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
package adminvoter;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author abhimanyuyadav
 */
public class updatePrefectsJC implements Runnable {

    ArrayList<Integer> arcode;
    ArrayList<Integer> bicode;
    ArrayList<Integer> hacode;
    ArrayList<Integer> macode;
    int pno;

    public updatePrefectsJC(ArrayList<Integer> arcode, ArrayList<Integer> bicode, ArrayList<Integer> hacode, ArrayList<Integer> macode,int pno) {
        this.arcode = arcode;
        this.bicode = bicode;
        this.hacode = hacode;
        this.macode = macode;
        this.pno = pno;
    }

    @Override
    public void run() {

        try {
            String url = "jdbc:mysql://localhost:3306/TBS?zeroDateTimeBehavior=CONVERT_TO_NULL";
            String user = "root";
            String pass = "TBS@admin123";

            Connection conn = DriverManager.getConnection(url, user, pass);
            Statement st = conn.createStatement();
            String q1 = "SELECT * FROM CANDIDATE_BOYS";
            String q2 = "SELECT * FROM CANDIDATE_GIRLS";
            ResultSet rs = st.executeQuery(q1);
            ResultSet rs2 = st.executeQuery(q2);
            PreparedStatement pstmt = conn.prepareStatement("INSERT INTO tbs.prefects (`NAME`, HOUSE, PHOTO, CODE) VALUES (?, ?, ?, ?)");
            int i = 0;
            while(rs.next())
            {
                if(check(rs.getInt("CODE")))
                {
                    pstmt.setString(1, rs.getString("NAME"));
                    pstmt.setString(2, rs.getString("HOUSE"));
                    pstmt.setBlob(3, rs.getBlob("PHOTO"));
                    pstmt.setInt(4, rs.getInt("CODE"));
                    pstmt.executeUpdate();
                }
            }
            while(rs2.next())
            {
                if(check(rs.getInt("CODE")))
                {
                    pstmt.setString(1, rs.getString("NAME"));
                    pstmt.setString(2, rs.getString("HOUSE"));
                    pstmt.setBlob(3, rs.getBlob("PHOTO"));
                    pstmt.setInt(4, rs.getInt("CODE"));
                    pstmt.executeUpdate();
                }
            }
            
        } catch (Exception e) {

            e.printStackTrace();
        }

    }
    
    private boolean check(int code)
    {
        for(int i=0;i<pno*2;i++)
        {
            if(code == arcode.get(i)||code == bicode.get(i)||code == hacode.get(i)||code == macode.get(i))
            return true;
        }
        
        return false;
    }

}
