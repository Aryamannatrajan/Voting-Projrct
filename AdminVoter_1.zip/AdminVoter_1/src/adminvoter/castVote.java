/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package adminvoter;

import java.awt.Image;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author abhimanyuyadav
 */
public class castVote implements Runnable {

    String gender;
    int comp_code;
    String part;
    AdMain4JCExtend ad;
    AdMainVote adv;
    
    String name;
    String house;
    Blob photo;
    int code;

    public castVote(String gender, int comp_code, String part, AdMain4JCExtend ad, AdMainVote adv) {

        this.gender = gender;
        this.comp_code = comp_code;
        this.part = part;
        this.ad = ad;
        this.adv = adv;
    }

    @Override
    public void run() {
        try {
            int vote = 0;
            String urL = "jdbc:mysql://localhost:3306/TBS?zeroDateTimeBehavior=CONVERT_TO_NULL";
            String user = "root";
            String pass = "TBS@admin123";
            Connection conn = DriverManager.getConnection(urL, user, pass);
            Statement st = conn.createStatement();

            String query = "SELECT * FROM CANDIDATE_" + gender + " ORDER BY VOTES DESC";
            ResultSet rs = st.executeQuery(query);

            while (rs.next()) {
                int code = rs.getInt("CODE");
                if (code == comp_code) {
                    vote = rs.getInt("VOTES");
                    name = rs.getString("NAME");
                    house = rs.getString("HOUSE");
                    photo = rs.getBlob("PHOTO");
                    this.code = rs.getInt("CODE");
                    break;
                }
            }
            vote += 1;
            System.out.println(vote);
            PreparedStatement pstmt = conn.prepareStatement("UPDATE tbs.candidate_" + gender + " set `VOTES`= ? where CODE = ?");
            pstmt.setInt(1, vote);
            pstmt.setInt(2, comp_code);
            pstmt.executeUpdate();
            System.out.println("Successful");
            //AdMain4JCExtend ob = new AdMain4JCExtend();
            ad.updateWJC(st, query, conn, part, gender);
            ad.Conduct.setEnabled(true);
            ad.partGIF.setIcon(new javax.swing.ImageIcon(getClass().getResource("/adminvoter/greenMark.png")));
            ad.jLabel4.setText("Completed");
            adv.setVisible(false);

        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
