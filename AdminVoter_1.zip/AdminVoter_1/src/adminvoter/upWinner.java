/*
 * Copyright (C) 2020 abhimanyuyadav
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
package adminvoter;

import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

/**
 *
 * @author abhimanyuyadav
 */
public class upWinner {
    
    public void update(String name, String house, Blob photo, int code, String position,String gender)
    {
        try
        {
            String urL = "jdbc:mysql://localhost:3306/TBS?zeroDateTimeBehavior=CONVERT_TO_NULL";
            String user = "root";
            String pass = "TBS@admin123";
            Connection conn = DriverManager.getConnection(urL, user, pass);
            
            int x;
            System.out.println(gender);
            if (gender.equals("BOYS")) {
                x = 3;
            } else {
                x = 4;
            }
            System.out.println(name + " " + position);

//            PreparedStatement pstmt1 = conn.prepareStatement("DELETE FROM tbs.candidate_" + gender + " WHERE CODE = ?");
//            pstmt1.setInt(1, code);
//            pstmt1.executeUpdate();
            PreparedStatement pstmt2 = conn.prepareStatement("UPDATE tbs." + gender.substring(0, x) + "_WINNERS SET `NAME` = ?, HOUSE = ?, PHOTO = ?,CODE = ? WHERE `POSITION` = ?");
            pstmt2.setString(1, name);
            pstmt2.setString(2, house);
            pstmt2.setBlob(3, photo);
            pstmt2.setInt(4, code);
            pstmt2.setString(5, position);
            int a = pstmt2.executeUpdate();
            System.out.println(a);
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
    }
    
}
