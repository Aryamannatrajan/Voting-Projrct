/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adminvoter;

import com.placeholder.PlaceHolder;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JViewport;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import java.sql.*;
import javax.swing.ImageIcon;
import javax.swing.JPanel;

/**
 *
 * @author abhimanyuyadav
 */
public class AdMain4SR extends javax.swing.JFrame {

    /**
     * Creates new form AdMain4SR
     */
    PlaceHolder ph;
    JFrame jf[];
    JLabel jl[];
    ArrayList<String> hbimames;
    ArrayList<String> hbname;
    ArrayList<String> hbhouse;
    ArrayList<Integer> hbCode;

    ArrayList<String> hgimames;
    ArrayList<String> hgname;
    ArrayList<String> hghouse;
    ArrayList<Integer> hgCode;

    ArrayList<String> scbimames;
    ArrayList<String> scbname;
    ArrayList<String> scbhouse;
    ArrayList<Integer> scbCode;

    ArrayList<String> scgimames;
    ArrayList<String> scgname;
    ArrayList<String> scghouse;
    ArrayList<Integer> scgCode;

    ArrayList<String> arpimames;
    ArrayList<String> arpname;
    ArrayList<String> arphouse;
    ArrayList<Integer> arpCode;

    ArrayList<String> armimames;
    ArrayList<String> armname;
    ArrayList<String> armhouse;
    ArrayList<Integer> armCode;

    ArrayList<String> bipimames;
    ArrayList<String> bipname;
    ArrayList<String> biphouse;
    ArrayList<Integer> bipCode;

    ArrayList<String> bimimames;
    ArrayList<String> bimname;
    ArrayList<String> bimhouse;
    ArrayList<Integer> bimCode;

    ArrayList<String> hapimames;
    ArrayList<String> hapname;
    ArrayList<String> haphouse;
    ArrayList<Integer> hapCode;

    ArrayList<String> hamimames;
    ArrayList<String> hamname;
    ArrayList<String> hamhouse;
    ArrayList<Integer> hamCode;

    ArrayList<String> mapimames;
    ArrayList<String> mapname;
    ArrayList<String> maphouse;
    ArrayList<Integer> mapCode;

    ArrayList<String> mamimames;
    ArrayList<String> mamname;
    ArrayList<String> mamhouse;
    ArrayList<Integer> mamCode;
    JFileChooser jc;

    JTextField hbName[];
    JComboBox hbHouse[];
    JButton hbFile[];
    JLabel hbPreview[];
    JTextField hbcode[];

    JTextField hgName[];
    JComboBox hgHouse[];
    JButton hgFile[];
    JLabel hgPreview[];
    JTextField hgcode[];

    JTextField scbName[];
    JComboBox scbHouse[];
    JButton scbFile[];
    JLabel scbPreview[];
    JTextField scbcode[];

    JTextField arpName[];
    JComboBox arpHouse[];
    JButton arpFile[];
    JLabel arpPreview[];
    JTextField arpcode[];

    JTextField armName[];
    JComboBox armHouse[];
    JButton armFile[];
    JLabel armPreview[];
    JTextField armcode[];

    JTextField bipName[];
    JComboBox bipHouse[];
    JButton bipFile[];
    JLabel bipPreview[];
    JTextField bipcode[];

    JTextField bimName[];
    JComboBox bimHouse[];
    JButton bimFile[];
    JLabel bimPreview[];
    JTextField bimcode[];

    JTextField hapName[];
    JComboBox hapHouse[];
    JButton hapFile[];
    JLabel hapPreview[];
    JTextField hapcode[];

    JTextField hamName[];
    JComboBox hamHouse[];
    JButton hamFile[];
    JLabel hamPreview[];
    JTextField hamcode[];

    JTextField mapName[];
    JComboBox mapHouse[];
    JButton mapFile[];
    JLabel mapPreview[];
    JTextField mapcode[];

    JTextField mamName[];
    JComboBox mamHouse[];
    JButton mamFile[];
    JLabel mamPreview[];
    JTextField mamcode[];

    JTextField scgName[];
    JComboBox scgHouse[];
    JButton scgFile[];
    JLabel scgPreview[];
    JTextField scgcode[];
    int size; //apply every where

    public AdMain4SR(int size) {

        this.size = size;
        jc = new JFileChooser();
        this.setExtendedState(MAXIMIZED_BOTH);
        initializePreview();
        initialiseElements();
        initComponents();
        initialiseLists();
        place_H();

        hbimames = new ArrayList<>();
        hbname = new ArrayList<>();
        hbhouse = new ArrayList<>();

    }

    private void initialiseElements() {
        hbName = new JTextField[size];
        hbHouse = new JComboBox[size];
        hbFile = new JButton[size];
        hbPreview = new JLabel[size];
        hbcode = new JTextField[size];

        hgName = new JTextField[size];
        hgHouse = new JComboBox[size];
        hgFile = new JButton[size];
        hgPreview = new JLabel[size];
        hgcode = new JTextField[size];

        scbName = new JTextField[size];
        scbHouse = new JComboBox[size];
        scbFile = new JButton[size];
        scbPreview = new JLabel[size];
        scbcode = new JTextField[size];

        arpName = new JTextField[size];
        arpHouse = new JComboBox[size];
        arpFile = new JButton[size];
        arpPreview = new JLabel[size];
        arpcode = new JTextField[size];

        armName = new JTextField[size];
        armHouse = new JComboBox[size];
        armFile = new JButton[size];
        armPreview = new JLabel[size];
        armcode = new JTextField[size];

        bipName = new JTextField[size];
        bipHouse = new JComboBox[size];
        bipFile = new JButton[size];
        bipPreview = new JLabel[size];
        bipcode = new JTextField[size];

        bimName = new JTextField[size];
        bimHouse = new JComboBox[size];
        bimFile = new JButton[size];
        bimPreview = new JLabel[size];
        bimcode = new JTextField[size];

        hapName = new JTextField[size];
        hapHouse = new JComboBox[size];
        hapFile = new JButton[size];
        hapPreview = new JLabel[size];
        hapcode = new JTextField[size];

        hamName = new JTextField[size];
        hamHouse = new JComboBox[size];
        hamFile = new JButton[size];
        hamPreview = new JLabel[size];
        hamcode = new JTextField[size];

        mapName = new JTextField[size];
        mapHouse = new JComboBox[size];
        mapFile = new JButton[size];
        mapPreview = new JLabel[size];
        mapcode = new JTextField[size];

        mamName = new JTextField[size];
        mamHouse = new JComboBox[size];
        mamFile = new JButton[size];
        mamPreview = new JLabel[size];
        mamcode = new JTextField[size];

        scgName = new JTextField[size];
        scgHouse = new JComboBox[size];
        scgFile = new JButton[size];
        scgPreview = new JLabel[size];
        scgcode = new JTextField[size];
    }

    private void initialiseLists() {
        hbimames = new ArrayList<>();
        hbname = new ArrayList<>();
        hbhouse = new ArrayList<>();
        hbCode = new ArrayList<>();

        arpimames = new ArrayList<>();
        arpname = new ArrayList<>();
        arphouse = new ArrayList<>();
        arpCode = new ArrayList<>();

        armimames = new ArrayList<>();
        armname = new ArrayList<>();
        armhouse = new ArrayList<>();
        armCode = new ArrayList<>();

        bipimames = new ArrayList<>();
        bipname = new ArrayList<>();
        biphouse = new ArrayList<>();
        bipCode = new ArrayList<>();

        bimimames = new ArrayList<>();
        bimname = new ArrayList<>();
        bimhouse = new ArrayList<>();
        bimCode = new ArrayList<>();

        hapimames = new ArrayList<>();
        hapname = new ArrayList<>();
        haphouse = new ArrayList<>();
        hapCode = new ArrayList<>();

        hamimames = new ArrayList<>();
        hamname = new ArrayList<>();
        hamhouse = new ArrayList<>();
        hamCode = new ArrayList<>();

        mapimames = new ArrayList<>();
        mapname = new ArrayList<>();
        maphouse = new ArrayList<>();
        mapCode = new ArrayList<>();

        mamimames = new ArrayList<>();
        mamname = new ArrayList<>();
        mamhouse = new ArrayList<>();
        mamCode = new ArrayList<>();
    }

    private void getAndSendCandiates() {
        // Stores the names and house
        int ctr = 0;
        for (int i = 0; i < size; i++) {
            if (!(hbName[i].getText().contains("Candidate"))) {
                ctr++;
                hbname.add(i, hbName[i].getText());
                hbhouse.add(i, hbHouse[i].getSelectedItem().toString());
                System.out.println(hbname.get(i));
                System.out.println(hbhouse.get(i));
            }
        }
        System.out.println(ctr);
        // Writing the values in the database.
        try {
            String url = "jdbc:mysql://localhost:3306/TBS?zeroDateTimeBehavior=CONVERT_TO_NULL";
            String user = "root";
            String pass = "TBS@admin123";
            Connection conn = DriverManager.getConnection(url, user, pass);
            PreparedStatement pstmt = conn.prepareStatement("INSERT INTO tbs.candidate (`NAME`, HOUSE, PHOTO) VALUES (?, ?, ?)");

            FileInputStream fis;
            for (int i = 0; i < ctr; i++) {

                fis = new FileInputStream(hbimames.get(i));
                pstmt.setString(1, hbname.get(i));
                pstmt.setString(2, hbhouse.get(i));
                pstmt.setBlob(3, fis);

                pstmt.execute();
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(AdMain4SR.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void initDatabase() {
        Thread t = new Thread() {

            @Override
            public void run() {

                int ctr;
                ctr = getNames(hbname, hbhouse, hbCode, hbName, hbHouse, hbcode);
                sendValsB(hbname, hbhouse, hbimames, hbCode, "HEAD BOY", ctr);

//                ctr = getNames(hgname, hghouse, hgCode, hgName, hgHouse, hgcode);
//                sendValsG(hgname, hghouse, hgimames, hgCode, "HEAD GIRL", ctr);
//
//                ctr = getNames(scbname, scbhouse, scbCode, scbName, scbHouse, scbcode);
//                sendValsB(scbname, scbhouse, scbimames, scbCode, "SPORTS CAPTAIN", ctr);
//
//                ctr = getNames(scgname, scghouse, scgCode, scgName, scgHouse, scgcode);
//                sendValsG(scgname, scghouse, scgimames, scgCode, "SPORTS CAPTAIN", ctr);

                ctr = getNamesPre(arpname, arphouse, arpCode, arpName, "Arnould", arpcode);
                sendValsB(arpname, arphouse, arpimames, arpCode, "ARNOULD HOUSE PREFECTS", ctr);

                ctr = getNamesPre(armname, armhouse, armCode, armName, "Arnould", armcode);
                sendValsG(armname, armhouse, armimames, armCode, "ARNOULD HOUSE MONITORS", ctr);

                ctr = getNamesPre(bipname, biphouse, bipCode, bipName, "Bishops", bipcode);
                sendValsB(bipname, biphouse, bipimames, bipCode, "BISHOPS HOUSE PREFECTS", ctr);

                ctr = getNamesPre(bimname, bimhouse, bimCode, bimName, "Bishops", bimcode);
                sendValsG(bimname, bimhouse, bimimames, bimCode, "BISHOPS HOUSE MONITORS", ctr);

                ctr = getNamesPre(hapname, haphouse, hapCode, hapName, "Harding", hapcode);
                sendValsB(hapname, haphouse, hapimames, hapCode, "HARDING HOUSE PREFECTS", ctr);

                ctr = getNamesPre(hamname, hamhouse, hamCode, hamName, "Harding", hamcode);
                sendValsG(hamname, hamhouse, hamimames, hamCode, "HARDING HOUSE MONITORS", ctr);

                ctr = getNamesPre(mapname, maphouse, mapCode, mapName, "Mansfield", mapcode);
                sendValsB(mapname, maphouse, mapimames, mapCode, "MANSFIELD HOUSE PREFECTS", ctr);

                ctr = getNamesPre(mamname, mamhouse, mamCode, mamName, "Mansfield", mamcode);
                sendValsG(mamname, mamhouse, mamimames, mamCode, "MANSFELD HOUSE MONITORS", ctr);

            }

        };
        t.start();
    }

    private int getNames(ArrayList<String> name, ArrayList<String> house, ArrayList<Integer> code, JTextField Name[], JComboBox House[], JTextField Code[]) {
        int ctr = 0;
        for (int i = 0; i < size; i++) {
            if (!(Name[i].getText().contains("Candidate"))) {
                ctr++;
                name.add(i, Name[i].getText());
                house.add(i, House[i].getSelectedItem().toString());
                code.add(i, Integer.valueOf(Code[i].getText()));
                System.out.println(name.get(i));
                System.out.println(house.get(i));
            }
        }
        return ctr;
    }

    private int getNamesPre(ArrayList<String> name, ArrayList<String> house, ArrayList<Integer> code, JTextField Name[], String houses, JTextField Code[]) {
        int ctr = 0;
        for (int i = 0; i < size; i++) {
            if (!(Name[i].getText().contains("Candidate"))) {
                ctr++;
                name.add(i, Name[i].getText());
                house.add(i, houses);
                code.add(i, Integer.valueOf(Code[i].getText()));
                System.out.println(name.get(i));
                System.out.println(house.get(i));
            }
        }
        return ctr;
    }

    private void sendValsB(ArrayList<String> name, ArrayList<String> house, ArrayList<String> imames, ArrayList<Integer> code, String position, int ctr) {
        try {
            String url = "jdbc:mysql://localhost:3306/TBS?zeroDateTimeBehavior=CONVERT_TO_NULL";
            String user = "root";
            String pass = "TBS@admin123";
            Connection conn = DriverManager.getConnection(url, user, pass);
            PreparedStatement pstmt = conn.prepareStatement("INSERT INTO tbs.candidate (`NAME`, HOUSE, PHOTO, CODE, VOTES, `POSITION`) VALUES (?, ?, ?, ?, ?, ?)");

            FileInputStream fis;
            for (int i = 0; i < ctr; i++) {

                fis = new FileInputStream(imames.get(i));
                pstmt.setString(1, name.get(i));
                pstmt.setString(2, house.get(i));
                pstmt.setBlob(3, fis);
                pstmt.setInt(4, code.get(i));
                pstmt.setInt(5, 0);
                pstmt.setString(6, position);

                pstmt.execute();
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(AdMain4SR.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    private void sendValsG(ArrayList<String> name, ArrayList<String> house, ArrayList<String> imames, ArrayList<Integer> code, String position, int ctr) {
        try {
            String url = "jdbc:mysql://localhost:3306/TBS?zeroDateTimeBehavior=CONVERT_TO_NULL";
            String user = "root";
            String pass = "TBS@admin123";
            Connection conn = DriverManager.getConnection(url, user, pass);
            PreparedStatement pstmt = conn.prepareStatement("INSERT INTO tbs.candidate (`NAME`, HOUSE, PHOTO, CODE, VOTES, `POSITION`) VALUES (?, ?, ?, ?, ?, ?)");

            FileInputStream fis;
            for (int i = 0; i < ctr; i++) {

                fis = new FileInputStream(imames.get(i));
                pstmt.setString(1, name.get(i));
                pstmt.setString(2, house.get(i));
                pstmt.setBlob(3, fis);
                pstmt.setInt(4, code.get(i));
                pstmt.setInt(5, 0);
                pstmt.setString(6, position);

                pstmt.execute();
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(AdMain4SR.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    ActionListener hbImageChooser = new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            // Searches for the button which was pressed-
            // and returns to set the imame
            for (int i = 0; i < size; i++) {
                if (hbFile[i] == e.getSource()) {
                    setImage(i, hbimames);
                }
            }
        }

    };
    MouseListener hbPreviewer = new MouseListener() {
        @Override
        public void mouseClicked(MouseEvent e) {
            //   throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        @Override
        public void mousePressed(MouseEvent e) {
            //     throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        @Override
        public void mouseReleased(MouseEvent e) {
            JFrame jf[] = new JFrame[size];
            JLabel jl[] = new JLabel[size];
            initialiserPrev(jf, jl);
            for (int i = 0; i < size; i++) {
                if (hbPreview[i] == e.getSource()) {
                    jf[i].setVisible(true);
                    ImageIcon img = new ImageIcon(hbimames.get(i));
                    jl[i].setIcon(img);
                    jl[i].setVisible(true);
                }
            }

        }

        @Override
        public void mouseEntered(MouseEvent e) {
            //  throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        @Override
        public void mouseExited(MouseEvent e) {
            // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

    };
    ActionListener hgImageChooser = new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            // Searches for the button which was pressed-
            // and returns to set the imame
            for (int i = 0; i < size; i++) {
                if (hgFile[i] == e.getSource()) {
                    setImage(i, hgimames);
                }
            }
        }

    };

    private void initialiserPrev(JFrame[] jf, JLabel[] jl) {
        for (int i = 0; i < jf.length; i++) {
            jf[i] = new JFrame();
            jl[i] = new JLabel();
            for (int j = 0; j < size; j++) {
                jf[i] = new JFrame();
                jl[i] = new JLabel();
                jf[i].setBounds(550, 200, 275, 325);

                jf[i].setTitle("Preview ");
                jl[i].setBounds(900, 400, 233, 300);
                jf[i].add(jl[i]);
                jl[i].setAlignmentX(CENTER_ALIGNMENT);
                jl[i].setAlignmentY(CENTER_ALIGNMENT);
                jl[i].setVisible(true);

            }
        }

    }
//
//    MouseListener hgPreviewer = new MouseListener() {
//        @Override
//        public void mouseClicked(MouseEvent e) {
//            // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//        }
//
//        @Override
//        public void mousePressed(MouseEvent e) {
//            // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//        }
//
//        @Override
//        public void mouseReleased(MouseEvent e) {
//            JFrame jf[] = new JFrame[7];
//            JLabel jl[] = new JLabel[7];
//            initialiserPrev(jf, jl);
//            for (int i = 0; i < 7; i++) {
//                if (hgPreview[i] == e.getSource()) {
//                    try {
//                        ImageIcon img = new ImageIcon(hgimames.get(i));
//                        jl[i].setIcon(img);
//                    } catch (Exception ex) {
//                        jf[i].setVisible(true);
//                        ex.printStackTrace();
//                    }
//                    jf[i].setVisible(true);
//                    jl[i].setVisible(true);
//                }
//            }
//        }
//
//        @Override
//        public void mouseEntered(MouseEvent e) {
//            //  throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//        }
//
//        @Override
//        public void mouseExited(MouseEvent e) {
//            //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//        }
//
//    };
//    ActionListener scbImageChooser = new ActionListener() {
//        @Override
//        public void actionPerformed(ActionEvent e) {
//            // Searches for the button which was pressed-
//            // and returns to set the imame
//            for (int i = 0; i < 7; i++) {
//                if (scbFile[i] == e.getSource()) {
//                    setImage(i, scbimames);
//                }
//            }
//        }
//
//    };
//    MouseListener scbPreviewer = new MouseListener() {
//        @Override
//        public void mouseClicked(MouseEvent e) {
//            // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//        }
//
//        @Override
//        public void mousePressed(MouseEvent e) {
//            //  throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//        }
//
//        @Override
//        public void mouseReleased(MouseEvent e) {
//            JFrame jf[] = new JFrame[7];
//            JLabel jl[] = new JLabel[7];
//            initialiserPrev(jf, jl);
//            for (int i = 0; i < 7; i++) {
//                if (scbPreview[i] == e.getSource()) {
//                    ImageIcon img = new ImageIcon(scbimames.get(i));
//                    jl[i].setIcon(img);
//                    jf[i].setVisible(true);
//                    jl[i].setVisible(true);
//                }
//            }
//        }
//
//        @Override
//        public void mouseEntered(MouseEvent e) {
//            // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//        }
//
//        @Override
//        public void mouseExited(MouseEvent e) {
//            //  throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//        }
//
//    };
//    ActionListener scgImageChooser = new ActionListener() {
//        @Override
//        public void actionPerformed(ActionEvent e) {
//            // Searches for the button which was pressed-
//            // and returns to set the imame
//            for (int i = 0; i < 7; i++) {
//                if (scgFile[i] == e.getSource()) {
//                    setImage(i, scgimames);
//                }
//            }
//        }
//
//    };
//    MouseListener scgPreviewer = new MouseListener() {
//        @Override
//        public void mouseClicked(MouseEvent e) {
//            // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//        }
//
//        @Override
//        public void mousePressed(MouseEvent e) {
//            //  throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//        }
//
//        @Override
//        public void mouseReleased(MouseEvent e) {
//            JFrame jf[] = new JFrame[7];
//            JLabel jl[] = new JLabel[7];
//            initialiserPrev(jf, jl);
//            for (int i = 0; i < 7; i++) {
//                if (scgPreview[i] == e.getSource()) {
//                    ImageIcon img = new ImageIcon(scgimames.get(i));
//                    jl[i].setIcon(img);
//                    jf[i].setVisible(true);
//                    jl[i].setVisible(true);
//                }
//            }
//        }
//
//        @Override
//        public void mouseEntered(MouseEvent e) {
//            // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//        }
//
//        @Override
//        public void mouseExited(MouseEvent e) {
//            //  throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//        }
//
//    };

    ActionListener armImageChooser = new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            // Searches for the button which was pressed-
            // and returns to set the imame
            for (int i = 0; i < size; i++) {
                if (armFile[i] == e.getSource()) {
                    setImage(i, armimames);
                }
            }
        }

    };
    MouseListener armPreviewer = new MouseListener() {
        @Override
        public void mouseClicked(MouseEvent e) {
            // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        @Override
        public void mousePressed(MouseEvent e) {
            //  throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        @Override
        public void mouseReleased(MouseEvent e) {
            JFrame jf[] = new JFrame[size];
            JLabel jl[] = new JLabel[size];
            initialiserPrev(jf, jl);
            for (int i = 0; i < size; i++) {
                if (armPreview[i] == e.getSource()) {
                    ImageIcon img = new ImageIcon(armimames.get(i));
                    jl[i].setIcon(img);
                    jf[i].setVisible(true);
                    jl[i].setVisible(true);
                }
            }
        }

        @Override
        public void mouseEntered(MouseEvent e) {
            // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        @Override
        public void mouseExited(MouseEvent e) {
            //  throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

    };

    ActionListener arpImageChooser = new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            // Searches for the button which was pressed-
            // and returns to set the imame
            for (int i = 0; i < size; i++) {
                if (arpFile[i] == e.getSource()) {
                    setImage(i, arpimames);
                }
            }
        }

    };
    MouseListener arpPreviewer = new MouseListener() {
        @Override
        public void mouseClicked(MouseEvent e) {
            // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        @Override
        public void mousePressed(MouseEvent e) {
            //  throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        @Override
        public void mouseReleased(MouseEvent e) {
            JFrame jf[] = new JFrame[size];
            JLabel jl[] = new JLabel[size];
            initialiserPrev(jf, jl);
            for (int i = 0; i < size; i++) {
                if (arpPreview[i] == e.getSource()) {
                    ImageIcon img = new ImageIcon(arpimames.get(i));
                    jl[i].setIcon(img);
                    jf[i].setVisible(true);
                    jl[i].setVisible(true);
                }
            }
        }

        @Override
        public void mouseEntered(MouseEvent e) {
            // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        @Override
        public void mouseExited(MouseEvent e) {
            //  throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

    };

    //Bishops
    ActionListener bimImageChooser = new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            // Searches for the button which was pressed-
            // and returns to set the imame
            for (int i = 0; i < size; i++) {
                if (bimFile[i] == e.getSource()) {
                    setImage(i, bimimames);
                }
            }
        }

    };
    MouseListener bimPreviewer = new MouseListener() {
        @Override
        public void mouseClicked(MouseEvent e) {
            // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        @Override
        public void mousePressed(MouseEvent e) {
            //  throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        @Override
        public void mouseReleased(MouseEvent e) {
            JFrame jf[] = new JFrame[size];
            JLabel jl[] = new JLabel[size];
            initialiserPrev(jf, jl);
            for (int i = 0; i < size; i++) {
                if (bimPreview[i] == e.getSource()) {
                    ImageIcon img = new ImageIcon(bimimames.get(i));
                    jl[i].setIcon(img);
                    jf[i].setVisible(true);
                    jl[i].setVisible(true);
                }
            }
        }

        @Override
        public void mouseEntered(MouseEvent e) {
            // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        @Override
        public void mouseExited(MouseEvent e) {
            //  throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

    };

    ActionListener bipImageChooser = new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            // Searches for the button which was pressed-
            // and returns to set the imame
            for (int i = 0; i < size; i++) {
                if (bipFile[i] == e.getSource()) {
                    setImage(i, bipimames);
                }
            }
        }

    };
    MouseListener bipPreviewer = new MouseListener() {
        @Override
        public void mouseClicked(MouseEvent e) {
            // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        @Override
        public void mousePressed(MouseEvent e) {
            //  throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        @Override
        public void mouseReleased(MouseEvent e) {
            JFrame jf[] = new JFrame[size];
            JLabel jl[] = new JLabel[size];
            initialiserPrev(jf, jl);
            for (int i = 0; i < size; i++) {
                if (bipPreview[i] == e.getSource()) {
                    ImageIcon img = new ImageIcon(bipimames.get(i));
                    jl[i].setIcon(img);
                    jf[i].setVisible(true);
                    jl[i].setVisible(true);
                }
            }
        }

        @Override
        public void mouseEntered(MouseEvent e) {
            // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        @Override
        public void mouseExited(MouseEvent e) {
            //  throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

    };

    //Harding
    ActionListener hamImageChooser = new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            // Searches for the button which was pressed-
            // and returns to set the imame
            for (int i = 0; i < size; i++) {
                if (hamFile[i] == e.getSource()) {
                    setImage(i, hamimames);
                }
            }
        }

    };
    MouseListener hamPreviewer = new MouseListener() {
        @Override
        public void mouseClicked(MouseEvent e) {
            // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        @Override
        public void mousePressed(MouseEvent e) {
            //  throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        @Override
        public void mouseReleased(MouseEvent e) {
            JFrame jf[] = new JFrame[size];
            JLabel jl[] = new JLabel[size];
            initialiserPrev(jf, jl);
            for (int i = 0; i < size; i++) {
                if (hamPreview[i] == e.getSource()) {
                    ImageIcon img = new ImageIcon(hamimames.get(i));
                    jl[i].setIcon(img);
                    jf[i].setVisible(true);
                    jl[i].setVisible(true);
                }
            }
        }

        @Override
        public void mouseEntered(MouseEvent e) {
            // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        @Override
        public void mouseExited(MouseEvent e) {
            //  throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

    };

    ActionListener hapImageChooser = new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            // Searches for the button which was pressed-
            // and returns to set the imame
            for (int i = 0; i <size; i++) {
                if (hapFile[i] == e.getSource()) {
                    setImage(i, hapimames);
                }
            }
        }

    };
    MouseListener hapPreviewer = new MouseListener() {
        @Override
        public void mouseClicked(MouseEvent e) {
            // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        @Override
        public void mousePressed(MouseEvent e) {
            //  throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        @Override
        public void mouseReleased(MouseEvent e) {
            JFrame jf[] = new JFrame[size];
            JLabel jl[] = new JLabel[size];
            initialiserPrev(jf, jl);
            for (int i = 0; i < size; i++) {
                if (hapPreview[i] == e.getSource()) {
                    ImageIcon img = new ImageIcon(hapimames.get(i));
                    jl[i].setIcon(img);
                    jf[i].setVisible(true);
                    jl[i].setVisible(true);
                }
            }
        }

        @Override
        public void mouseEntered(MouseEvent e) {
            // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        @Override
        public void mouseExited(MouseEvent e) {
            //  throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

    };

    // mansfield
    ActionListener mamImageChooser = new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            // Searches for the button which was pressed-
            // and returns to set the imame
            for (int i = 0; i < size; i++) {
                if (mamFile[i] == e.getSource()) {
                    setImage(i, mamimames);
                }
            }
        }

    };
    MouseListener mamPreviewer = new MouseListener() {
        @Override
        public void mouseClicked(MouseEvent e) {
            // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        @Override
        public void mousePressed(MouseEvent e) {
            //  throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        @Override
        public void mouseReleased(MouseEvent e) {
            JFrame jf[] = new JFrame[size];
            JLabel jl[] = new JLabel[size];
            initialiserPrev(jf, jl);
            for (int i = 0; i < size; i++) {
                if (mamPreview[i] == e.getSource()) {
                    ImageIcon img = new ImageIcon(mamimames.get(i));
                    jl[i].setIcon(img);
                    jf[i].setVisible(true);
                    jl[i].setVisible(true);
                }
            }
        }

        @Override
        public void mouseEntered(MouseEvent e) {
            // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        @Override
        public void mouseExited(MouseEvent e) {
            //  throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

    };

    ActionListener mapImageChooser = new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            // Searches for the button which was pressed-
            // and returns to set the imame
            for (int i = 0; i < size; i++) {
                if (mapFile[i] == e.getSource()) {
                    setImage(i, mapimames);
                }
            }
        }

    };
    MouseListener mapPreviewer = new MouseListener() {
        @Override
        public void mouseClicked(MouseEvent e) {
            // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        @Override
        public void mousePressed(MouseEvent e) {
            //  throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        @Override
        public void mouseReleased(MouseEvent e) {
            JFrame jf[] = new JFrame[size];
            JLabel jl[] = new JLabel[size];
            initialiserPrev(jf, jl);
            for (int i = 0; i < size; i++) {
                if (mapPreview[i] == e.getSource()) {
                    ImageIcon img = new ImageIcon(mapimames.get(i));
                    jl[i].setIcon(img);
                    jf[i].setVisible(true);
                    jl[i].setVisible(true);
                }
            }
        }

        @Override
        public void mouseEntered(MouseEvent e) {
            // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        @Override
        public void mouseExited(MouseEvent e) {
            //  throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

    };

    private void setImage(int i, ArrayList<String> imames) {
        try {

            jc.setSelectedFile(null);
            jc.showOpenDialog(null);
            File f = jc.getSelectedFile();
            imames.add(i, f.getAbsolutePath());

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    private void initializePanels(JPanel panel, JTextField canName[], JComboBox canHouse[], JButton canFile[], JLabel canPreview[], JTextField cancode[], int size) {
        // Intialising each value to it's respective class (Avoids NullPointerException).
        for (int i = 0; i < size; i++) {
            canName[i] = new JTextField();
            canHouse[i] = new JComboBox();
            canFile[i] = new JButton();
            canPreview[i] = new JLabel();
            cancode[i] = new JTextField();
        }

        // Setting the location
        for (int i = 0; i < size; i++) {
            canName[i].setBounds(0, 50 + 35 * i, 160, 35);

            cancode[i].setBounds(400, 50 + 35 * i, 60, 30);
            cancode[i].setToolTipText("Enter Computer Code");
            ph = new PlaceHolder(cancode[i], "code");
            ph = new PlaceHolder(canName[i], "Candidate " + (i + 1));
            canHouse[i].setBounds(165, 50 + 35 * i + 5, 100, 25);
            canHouse[i].setModel(new javax.swing.DefaultComboBoxModel<>(new String[]{"House*", "Arnould", "Bishops", "Harding", "Mansfield"}));
            canFile[i].setText("Choose File");
            canFile[i].setFont(new java.awt.Font("Lucida Grande", 0, 9));
            canFile[i].setBounds(275, 50 + 35 * i + 5, 90, 20);
            Image imame;
            try {
                imame = ImageIO.read(getClass().getResourceAsStream("eyeicn2.png"));
                ImageIcon img = new ImageIcon(imame);
                canPreview[i].setIcon(img);
            } catch (IOException ex) {
                Logger.getLogger(AdMain4SR.class.getName()).log(Level.SEVERE, null, ex);
            }

            canPreview[i].setBounds(375, 50 + 35 * i, 30, 30);
            canPreview[i].setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        }

        // Adding Action Listener and MouseListener and Adding it to the hbPanel
        for (int i = 0; i < size; i++) {
            canName[i].setVisible(true);
            canHouse[i].setVisible(true);
            canFile[i].setVisible(true);
            canPreview[i].setVisible(true);
            cancode[i].setVisible(true);

            panel.add(canName[i]);
            panel.add(canHouse[i]);
            panel.add(canFile[i]);
            panel.add(canPreview[i]);
            panel.add(cancode[i]);

            canFile[i].addActionListener(hbImageChooser);
            canPreview[i].addMouseListener(hbPreviewer);
//            canFile[i].addActionListener(hgImageChooser);
//            canPreview[i].addMouseListener(hgPreviewer);
//            canFile[i].addActionListener(scbImageChooser);
//            canPreview[i].addMouseListener(scbPreviewer);
//
//            canFile[i].addActionListener(scgImageChooser);
//            canPreview[i].addMouseListener(scgPreviewer);

            canFile[i].addActionListener(arpImageChooser);
            canPreview[i].addMouseListener(arpPreviewer);
            canFile[i].addActionListener(armImageChooser);
            canPreview[i].addMouseListener(armPreviewer);

            canFile[i].addActionListener(bipImageChooser);
            canPreview[i].addMouseListener(bipPreviewer);
            canFile[i].addActionListener(bimImageChooser);
            canPreview[i].addMouseListener(bimPreviewer);

            canFile[i].addActionListener(hapImageChooser);
            canPreview[i].addMouseListener(hapPreviewer);
            canFile[i].addActionListener(hamImageChooser);
            canPreview[i].addMouseListener(hamPreviewer);

            canFile[i].addActionListener(mapImageChooser);
            canPreview[i].addMouseListener(mapPreviewer);
            canFile[i].addActionListener(mamImageChooser);
            canPreview[i].addMouseListener(mamPreviewer);

        }

    }

    private void initializePanelsH(JPanel panel, JTextField canName[], JComboBox house[], JButton canFile[], JLabel canPreview[], JTextField cancode[], int size) {
        // Intialising each value to it's respective class (Avoids NullPointerException).
        for (int i = 0; i < size; i++) {
            canName[i] = new JTextField();

            canFile[i] = new JButton();
            canPreview[i] = new JLabel();
            cancode[i] = new JTextField();
        }

        // Setting the location
        for (int i = 0; i < size; i++) {
            canName[i].setBounds(0, 50 + 35 * i, 160, 35);

            cancode[i].setBounds(400, 50 + 35 * i, 60, 30);
            cancode[i].setToolTipText("Enter Computer Code");
            ph = new PlaceHolder(cancode[i], "code");
            ph = new PlaceHolder(canName[i], "Candidate " + (i + 1));

            canFile[i].setText("Choose File");
            canFile[i].setFont(new java.awt.Font("Lucida Grande", 0, 9));
            canFile[i].setBounds(275, 50 + 35 * i + 5, 90, 20);
            Image imame;
            try {
                imame = ImageIO.read(getClass().getResourceAsStream("eyeicn2.png"));
                ImageIcon img = new ImageIcon(imame);
                canPreview[i].setIcon(img);
            } catch (IOException ex) {
                Logger.getLogger(AdMain4SR.class.getName()).log(Level.SEVERE, null, ex);
            }

            canPreview[i].setBounds(375, 50 + 35 * i, 30, 30);
            canPreview[i].setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        }

        // Adding Action Listener and MouseListener and Adding it to the hbPanel
        for (int i = 0; i < size; i++) {
            canName[i].setVisible(true);

            canFile[i].setVisible(true);
            canPreview[i].setVisible(true);
            cancode[i].setVisible(true);

            panel.add(canName[i]);

            panel.add(canFile[i]);
            panel.add(canPreview[i]);
            panel.add(cancode[i]);

            canFile[i].addActionListener(hbImageChooser);
            canPreview[i].addMouseListener(hbPreviewer);
            canFile[i].addActionListener(hgImageChooser);
//            canPreview[i].addMouseListener(hgPreviewer);
//            canFile[i].addActionListener(scbImageChooser);
//            canPreview[i].addMouseListener(scbPreviewer);
//
//            canFile[i].addActionListener(scgImageChooser);
//            canPreview[i].addMouseListener(scgPreviewer);

            canFile[i].addActionListener(arpImageChooser);
            canPreview[i].addMouseListener(arpPreviewer);
            canFile[i].addActionListener(armImageChooser);
            canPreview[i].addMouseListener(armPreviewer);

            canFile[i].addActionListener(bipImageChooser);
            canPreview[i].addMouseListener(bipPreviewer);
            canFile[i].addActionListener(bimImageChooser);
            canPreview[i].addMouseListener(bimPreviewer);

            canFile[i].addActionListener(hapImageChooser);
            canPreview[i].addMouseListener(hapPreviewer);
            canFile[i].addActionListener(hamImageChooser);
            canPreview[i].addMouseListener(hamPreviewer);

            canFile[i].addActionListener(mapImageChooser);
            canPreview[i].addMouseListener(mapPreviewer);
            canFile[i].addActionListener(mamImageChooser);
            canPreview[i].addMouseListener(mamPreviewer);

        }

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jDialog1 = new javax.swing.JDialog();
        jDialog2 = new javax.swing.JDialog();
        jDialog3 = new javax.swing.JDialog();
        jDialog4 = new javax.swing.JDialog();
        jFrame1 = new javax.swing.JFrame();
        jDialog5 = new javax.swing.JDialog();
        jFrame2 = new javax.swing.JFrame();
        jDialog6 = new javax.swing.JDialog();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jPanel4 = new javax.swing.JPanel();
        hbPanel = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jPanel17 = new javax.swing.JPanel();
        jLabel27 = new javax.swing.JLabel();
        jPanel24 = new javax.swing.JPanel();
        jLabel40 = new javax.swing.JLabel();
        jPanel34 = new javax.swing.JPanel();
        jLabel59 = new javax.swing.JLabel();
        jPanel44 = new javax.swing.JPanel();
        jLabel78 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        filler1 = new javax.swing.Box.Filler(new java.awt.Dimension(0, 0), new java.awt.Dimension(0, 0), new java.awt.Dimension(32767, 32767));
        jButton1 = new javax.swing.JButton();

        javax.swing.GroupLayout jDialog1Layout = new javax.swing.GroupLayout(jDialog1.getContentPane());
        jDialog1.getContentPane().setLayout(jDialog1Layout);
        jDialog1Layout.setHorizontalGroup(
            jDialog1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        jDialog1Layout.setVerticalGroup(
            jDialog1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jDialog2Layout = new javax.swing.GroupLayout(jDialog2.getContentPane());
        jDialog2.getContentPane().setLayout(jDialog2Layout);
        jDialog2Layout.setHorizontalGroup(
            jDialog2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        jDialog2Layout.setVerticalGroup(
            jDialog2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jDialog3Layout = new javax.swing.GroupLayout(jDialog3.getContentPane());
        jDialog3.getContentPane().setLayout(jDialog3Layout);
        jDialog3Layout.setHorizontalGroup(
            jDialog3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        jDialog3Layout.setVerticalGroup(
            jDialog3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jDialog4Layout = new javax.swing.GroupLayout(jDialog4.getContentPane());
        jDialog4.getContentPane().setLayout(jDialog4Layout);
        jDialog4Layout.setHorizontalGroup(
            jDialog4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        jDialog4Layout.setVerticalGroup(
            jDialog4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jFrame1Layout = new javax.swing.GroupLayout(jFrame1.getContentPane());
        jFrame1.getContentPane().setLayout(jFrame1Layout);
        jFrame1Layout.setHorizontalGroup(
            jFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        jFrame1Layout.setVerticalGroup(
            jFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jDialog5Layout = new javax.swing.GroupLayout(jDialog5.getContentPane());
        jDialog5.getContentPane().setLayout(jDialog5Layout);
        jDialog5Layout.setHorizontalGroup(
            jDialog5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        jDialog5Layout.setVerticalGroup(
            jDialog5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jFrame2Layout = new javax.swing.GroupLayout(jFrame2.getContentPane());
        jFrame2.getContentPane().setLayout(jFrame2Layout);
        jFrame2Layout.setHorizontalGroup(
            jFrame2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        jFrame2Layout.setVerticalGroup(
            jFrame2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jDialog6Layout = new javax.swing.GroupLayout(jDialog6.getContentPane());
        jDialog6.getContentPane().setLayout(jDialog6Layout);
        jDialog6Layout.setHorizontalGroup(
            jDialog6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        jDialog6Layout.setVerticalGroup(
            jDialog6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setPreferredSize(new java.awt.Dimension(1200, 919));

        jScrollPane2.setBorder(null);
        jScrollPane2.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        /*
        jScrollPane2.setToolTipText("");
        */
        jScrollPane2.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        jScrollPane2.getVerticalScrollBar().setUnitIncrement(7);
        jScrollPane2.getViewport ().setScrollMode ( JViewport.BACKINGSTORE_SCROLL_MODE );

        jPanel4.setForeground(new java.awt.Color(153, 153, 153));

        hbPanel.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        initializePanels(hbPanel,hbName,hbHouse,hbFile,hbPreview, hbcode,size);

        jLabel2.setFont(new java.awt.Font("Times", 1, 27)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("HEAD BOY");
        jLabel2.setToolTipText("");

        javax.swing.GroupLayout hbPanelLayout = new javax.swing.GroupLayout(hbPanel);
        hbPanel.setLayout(hbPanelLayout);
        hbPanelLayout.setHorizontalGroup(
            hbPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(hbPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, 473, Short.MAX_VALUE)
                .addContainerGap())
        );
        hbPanelLayout.setVerticalGroup(
            hbPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(hbPanelLayout.createSequentialGroup()
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 367, Short.MAX_VALUE))
        );

        jPanel17.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        initializePanelsH(jPanel17,armName,armHouse,armFile,armPreview, armcode,size);

        jLabel27.setFont(new java.awt.Font("PT Serif Caption", 1, 30)); // NOI18N
        jLabel27.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel27.setText("Monitors");

        javax.swing.GroupLayout jPanel17Layout = new javax.swing.GroupLayout(jPanel17);
        jPanel17.setLayout(jPanel17Layout);
        jPanel17Layout.setHorizontalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel17Layout.createSequentialGroup()
                .addComponent(jLabel27, javax.swing.GroupLayout.DEFAULT_SIZE, 454, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel17Layout.setVerticalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel17Layout.createSequentialGroup()
                .addComponent(jLabel27, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 392, Short.MAX_VALUE))
        );

        jPanel24.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        initializePanelsH(jPanel24,arpName,arpHouse,arpFile,arpPreview, arpcode,size);

        jLabel40.setFont(new java.awt.Font("PT Serif Caption", 1, 30)); // NOI18N
        jLabel40.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel40.setText("Prefects");

        javax.swing.GroupLayout jPanel24Layout = new javax.swing.GroupLayout(jPanel24);
        jPanel24.setLayout(jPanel24Layout);
        jPanel24Layout.setHorizontalGroup(
            jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel24Layout.createSequentialGroup()
                .addComponent(jLabel40, javax.swing.GroupLayout.DEFAULT_SIZE, 472, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel24Layout.setVerticalGroup(
            jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel24Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel40, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(378, Short.MAX_VALUE))
        );

        jPanel34.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        initializePanelsH(jPanel34,bipName,bipHouse,bipFile,bipPreview, bipcode,size);

        jLabel59.setFont(new java.awt.Font("PT Serif Caption", 1, 30)); // NOI18N
        jLabel59.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel59.setText("Prefects");

        javax.swing.GroupLayout jPanel34Layout = new javax.swing.GroupLayout(jPanel34);
        jPanel34.setLayout(jPanel34Layout);
        jPanel34Layout.setHorizontalGroup(
            jPanel34Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel34Layout.createSequentialGroup()
                .addComponent(jLabel59, javax.swing.GroupLayout.DEFAULT_SIZE, 488, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel34Layout.setVerticalGroup(
            jPanel34Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel34Layout.createSequentialGroup()
                .addGap(2, 2, 2)
                .addComponent(jLabel59)
                .addContainerGap(384, Short.MAX_VALUE))
        );

        jPanel44.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        initializePanelsH(jPanel44,bimName,bimHouse,bimFile,bimPreview, bimcode,size);

        jLabel78.setFont(new java.awt.Font("PT Serif Caption", 1, 30)); // NOI18N
        jLabel78.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel78.setText("Monitors");

        javax.swing.GroupLayout jPanel44Layout = new javax.swing.GroupLayout(jPanel44);
        jPanel44.setLayout(jPanel44Layout);
        jPanel44Layout.setHorizontalGroup(
            jPanel44Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel44Layout.createSequentialGroup()
                .addContainerGap(34, Short.MAX_VALUE)
                .addComponent(jLabel78, javax.swing.GroupLayout.PREFERRED_SIZE, 429, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel44Layout.setVerticalGroup(
            jPanel44Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel44Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel78, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(377, Short.MAX_VALUE))
        );

        jButton3.setText("Submit");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Perpetua Titling MT", 1, 36)); // NOI18N
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("ARNOULD HOUSE");

        jLabel6.setFont(new java.awt.Font("Perpetua Titling MT", 1, 36)); // NOI18N
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel6.setText("BISHOPS HOUSE");

        jLabel7.setFont(new java.awt.Font("Perpetua Titling MT", 1, 36)); // NOI18N
        jLabel7.setText("HARDING HOUSE");

        jPanel3.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        initializePanelsH(jPanel3,hamName,hamHouse,hamFile,hamPreview, hamcode,size);

        jLabel8.setFont(new java.awt.Font("Perpetua", 1, 36)); // NOI18N
        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel8.setText("Monitors");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, 529, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(299, Short.MAX_VALUE))
        );

        jPanel5.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        initializePanelsH(jPanel5,hapName,hapHouse,hapFile,hapPreview, hapcode,size);

        jLabel9.setFont(new java.awt.Font("Perpetua", 1, 36)); // NOI18N
        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel9.setText("Prefects");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, 504, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(299, Short.MAX_VALUE))
        );

        jLabel10.setFont(new java.awt.Font("Perpetua Titling MT", 1, 36)); // NOI18N
        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel10.setText("MANSFIELD HOUSE");

        jPanel6.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        initializePanelsH(jPanel6,mapName,mapHouse,mapFile, mapPreview, mapcode,size);

        jLabel11.setFont(new java.awt.Font("Perpetua", 1, 36)); // NOI18N
        jLabel11.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel11.setText("Prefects");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 493, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(15, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(315, Short.MAX_VALUE))
        );

        jPanel7.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        initializePanelsH(jPanel7,mamName,mamHouse,mamFile,mamPreview, mamcode,size);

        jLabel12.setFont(new java.awt.Font("Perpetua", 1, 36)); // NOI18N
        jLabel12.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel12.setText("Monitors");

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(47, 47, 47)
                .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 368, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(58, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addGap(0, 779, Short.MAX_VALUE)
                .addComponent(jPanel17, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(988, 988, 988))
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(539, 539, 539)
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(566, 566, 566)
                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 338, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(535, 535, 535)
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 387, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(534, 534, 534)
                        .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 379, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(481, 481, 481)
                        .addComponent(hbPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(200, 200, 200)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel4Layout.createSequentialGroup()
                                    .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(jPanel4Layout.createSequentialGroup()
                                    .addComponent(jPanel44, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(41, 41, 41)))
                            .addComponent(jPanel24, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel34, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(659, 659, 659)
                        .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(hbPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel17, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel24, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel34, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel44, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(15, 15, 15)
                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jScrollPane2.setViewportView(jPanel4);

        jPanel2.setBackground(new java.awt.Color(163, 29, 36));

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 48)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 204, 51));
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/adminvoter/BLogo1 (1).png"))); // NOI18N
        jLabel1.setText("                 THE BISHOP'S SCHOOL,PUNE");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 1588, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(filler1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(filler1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        jButton1.setText("Back");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, 1449, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton1)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 1429, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(14, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 636, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(3382, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 1449, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 10, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 4191, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        new AdMain2().setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        int response = JOptionPane.showConfirmDialog(null, "Do you want to save this form?", "Confirm Save", JOptionPane.OK_CANCEL_OPTION);
        if (response == JOptionPane.OK_OPTION) {

            String pfNo = JOptionPane.showInputDialog(null, "Enter the number of prefects that will be elected:\n(Remeber: This number will remain same for boys and girls)", "number of Prefects", JOptionPane.QUESTION_MESSAGE);

            int pfno = Integer.valueOf(pfNo);
            initPno(pfno);
            initDatabase();

                        try {
                                new AdMain4JCExtend(pfno,true).setVisible(true);
                                this.setVisible(false);
                            } catch (IOException ex) {
                                Logger.getLogger(AdMain4SR.class.getName()).log(Level.SEVERE, null, ex);
                            }

        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void initPno(int pno) {
        try {
            String urL = "jdbc:mysql://localhost:3306/TBS?zeroDateTimeBehavior=CONVERT_TO_NULL";
            String user = "root";
            String pass = "TBS@admin123";
            Connection conn = DriverManager.getConnection(urL, user, pass);
            String q = "UPDATE tbs.PrefectsNo SET PNO = ? WHERE ID = ?";
            PreparedStatement pstmt = conn.prepareStatement(q);
            pstmt.setInt(1, pno);
            pstmt.setInt(2, 1);
            pstmt.executeUpdate();

        } catch (SQLException ex) {
            Logger.getLogger(AdMain4SR.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void initializePreview() {
        jf = new JFrame[100];
        jl = new JLabel[100];
        for (int i = 0; i < 100; i++) {
            jf[i] = new JFrame();
            jl[i] = new JLabel();
            jf[i].setBounds(550, 200, 275, 325);

            jf[i].setTitle("Preview ");
            jl[i].setBounds(900, 400, 233, 300);
            jf[i].add(jl[i]);
            jl[i].setAlignmentX(CENTER_ALIGNMENT);
            jl[i].setAlignmentY(CENTER_ALIGNMENT);
            jl[i].setVisible(true);
        }

    }

    public static byte[] convertFileContentToBlob(String filePathStr) throws IOException {
        RandomAccessFile randomAccessFile = new RandomAccessFile(filePathStr, "r");
        // initialize byte array with size equal to the size of the file
        byte[] fileContent = new byte[(int) randomAccessFile.length()];
        randomAccessFile.readFully(fileContent);
        randomAccessFile.close();
        return fileContent;
    }

    public void place_H() {

        for (int i = 0; i < 6; i++) {
            //    ph = new PlaceHolder(hbName[i], "Candidate " + (i + 1));
        }

    }

    /**
     * @param arms the command line arguments
     */
    public static void main(String arms[]) {

        try {
            /* Set the Nimbus look and feel */
            //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
            /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
            * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html
             */
            try {
                for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                    if ("Nimbus".equals(info.getName())) {
                        javax.swing.UIManager.setLookAndFeel(info.getClassName());
                        break;
                    }
                }
            } catch (ClassNotFoundException ex) {
                java.util.logging.Logger.getLogger(AdMain4SR.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
            } catch (InstantiationException ex) {
                java.util.logging.Logger.getLogger(AdMain4SR.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
            } catch (IllegalAccessException ex) {
                java.util.logging.Logger.getLogger(AdMain4SR.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
            } catch (javax.swing.UnsupportedLookAndFeelException ex) {
                java.util.logging.Logger.getLogger(AdMain4SR.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
            }
            //</editor-fold>

            /* Create and display the form */
            UIManager.setLookAndFeel("com.formdev.flatlaf.FlatLightLaf");
            // System.out.println(UIManager.getCrossPlatformLookAndFeelClassName());

        } catch (UnsupportedLookAndFeelException ex) {
            Logger.getLogger(AdMain4SR.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(AdMain4SR.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            Logger.getLogger(AdMain4SR.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            Logger.getLogger(AdMain4SR.class.getName()).log(Level.SEVERE, null, ex);
        }
        java.awt.EventQueue.invokeLater(() -> {
            new AdMain4SR(5).setVisible(true);
        });
        //</editor-fold>
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.Box.Filler filler1;
    private javax.swing.JPanel hbPanel;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton3;
    private javax.swing.JDialog jDialog1;
    private javax.swing.JDialog jDialog2;
    private javax.swing.JDialog jDialog3;
    private javax.swing.JDialog jDialog4;
    private javax.swing.JDialog jDialog5;
    private javax.swing.JDialog jDialog6;
    private javax.swing.JFrame jFrame1;
    private javax.swing.JFrame jFrame2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel59;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel78;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel24;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel34;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel44;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JScrollPane jScrollPane2;
    // End of variables declaration//GEN-END:variables
}
/*
int i = 4;
            setImage(i);
            if(jl[i].getDisabledIcon() != null)
            {
                file5.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
                file5.setText("Edit imame");
                file5.setBorder(null);
            }
int i=5;
        jf[i].setVisible(true);
        jl[i].setVisible(true);
 */
