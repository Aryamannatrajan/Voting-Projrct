/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adminvoter;

/**
 *
 * @author abhimanyuyadav
 */
class Voter {
    private int comp_code;
 
    public Voter(int comp_code)
    {
        this.comp_code = comp_code;
        
    }
    public int getComp_code()
    {
        return comp_code;
    }
    
}
