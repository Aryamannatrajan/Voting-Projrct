/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package adminvoter;

import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author abhimanyuyadav
 */
public class castVotePreSr implements Runnable {

    String gender;
    int prefects[];
    int ctr;
    ArrayList<String> name = new ArrayList<>();
    ArrayList<String> house = new ArrayList<>();
    ArrayList<Blob> photo = new ArrayList<>();
    ArrayList<Integer> code = new ArrayList<>();
    AdMainVote adv;
    AdMain4JCExtend add;
    int x;
    int prefect[];

    public castVotePreSr(String gender, int prefects[], int ctr, AdMainVote adv, AdMain4JCExtend add) {
        this.adv = adv;
        this.add = add;
        this.gender = gender;
        x = prefects.length;
        this.prefect = prefects;
        add(prefects);
        this.ctr = ctr;
        init();
    }
    
    private void init() {
        for (int i = x, k = 0; i < add.pNo; i++, k++) {
            if (add.part.equals("ARNOULD HOUSE PREFECTS")) {
                prefects[i] = add.arcode.get(k);
                System.out.println(add.arcode.get(k)+" arcode v   "+i+"  "+k);
            } else if (add.part.equals("BISHOPS HOUSE PREFECTS")) {
                prefects[i] = add.bicode.get(k);
            } else if (add.part.equals("HARDING HOUSE PREFECTS")) {
                prefects[i] = add.hacode.get(k);
            } else if (add.part.equals("MANSFIELD HOUSE PREFECTS")) {
                prefects[i] = add.macode.get(k);
            }
        }

    }

    private void add(int[] prefect) {
        prefects = new int[add.pNo];
        for (int i = 0; i < prefect.length; i++) {
            prefects[i] = prefect[i];
        }
    }

    private boolean contains(int el) {
        for (int i = 0; i < prefect.length; i++) {
            if (prefect[i] == el) {
                return true;
            }
        }
        return false;
    }

    @Override
    public void run() {
        try {
            String urL = "jdbc:mysql://localhost:3306/TBS?zeroDateTimeBehavior=CONVERT_TO_NULL";
            String user = "root";
            String pass = "TBS@admin123";
            Connection conn = DriverManager.getConnection(urL, user, pass);

            for (int i = 0; i < prefects.length; i++) {
                int vote = 0;

                Statement st = conn.createStatement();

                String query = "SELECT *FROM CANDIDATE ORDER BY VOTES DESC";
                ResultSet rs = st.executeQuery(query);

                while (rs.next()) {
                    vote = 0;
                    int code = rs.getInt("CODE");
                    if (code == prefects[i]) {
                        vote = rs.getInt("VOTES");
                        name.add(rs.getString("NAME"));
                        house.add(rs.getString("HOUSE"));
                        photo.add(rs.getBlob("PHOTO"));
                        this.code.add(rs.getInt("CODE"));
                        if (contains(code)) {
                            vote += 1;
                            PreparedStatement pstmt = conn.prepareStatement("UPDATE tbs.candidate set `VOTES`= ? where CODE = ?");
                            pstmt.setInt(1, vote);
                            pstmt.setInt(2, prefects[i]);
                            pstmt.executeUpdate();
                            System.out.println("Successful");
                        }
                        break;
                    }
                    
                }

            }

            System.out.println(name.size());
            add.updatePreJC(name, house, photo, code);
            add.partGIF.setIcon(new javax.swing.ImageIcon(getClass().getResource("/adminvoter/greenMark.png")));
            add.jLabel4.setText("Completed");
            add.Conduct.setEnabled(true);
            adv.setVisible(false);

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

}
