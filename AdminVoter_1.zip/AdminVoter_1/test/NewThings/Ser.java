/*
 * Copyright (C) 2020 abhimanyuyadav
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
package NewThings;

import java.awt.Desktop;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;

/**
 *
 * @author abhimanyuyadav
 */
public class Ser {
    
    public static void main(String args[])
    {
        ArrayList<BufferedImage> images = new ArrayList<>();
        ArrayList<String> words = new ArrayList<>();
        words.add("Abhimanyu");
        words.add("Dhirodaatto");
        words.add("Aryaman");
        File f = new File("/Users/abhimanyuyadav/Desktop/191234.jpg");
        BufferedImage bi;
        try {
            bi = ImageIO.read(f);
            images.add(bi);
            images.add(bi);
        } catch (IOException ex) {
            Logger.getLogger(Ser.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        try {
            ServerSocket ss = new ServerSocket(1234);
            Socket s = null;
            s = ss.accept();
            ObjectOutputStream os = new ObjectOutputStream(s.getOutputStream());
            os.writeObject(words);
            
//            File f = new File("/Users/abhimanyuyadav/Desktop/191234.jpg");
//            
//           for(int i=0;i<2;i++)
//           {
//                
//                BufferedImage bi = ImageIO.read(f);
//                ImageIO.write(bi, "JPG", s.getOutputStream());
//           }
//            System.out.println("Sent successfully");
            s.close();
            ss.close();
            
        } catch (IOException ex) {
            Logger.getLogger(Ser.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
}
