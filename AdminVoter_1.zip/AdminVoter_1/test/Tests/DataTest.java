/*
 * Copyright (C) 2020 abhimanyuyadav
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
package Tests;

import adminvoter.AdMain4JC;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author abhimanyuyadav
 */
public class DataTest {
    
    static byte x = 0;
    private static void test()
    {
        try{
            String url = "jdbc:mysql://localhost:3306/TBS?zeroDateTimeBehavior=CONVERT_TO_NULL";
            String user = "root";
            String pass = "TBS@admin123";
            Connection conn = DriverManager.getConnection(url, user, pass);
            PreparedStatement pstmt = conn.prepareStatement("INSERT INTO tbs.candidate_boys (`NAME`, HOUSE, PHOTO, VOTES, `POSITION`, ELECTED) VALUES (?, ?, ?, ?, ?, ?)");
            
            FileInputStream fis;
            for(int i=0;i<1;i++)
            {
                
                fis = new FileInputStream("/Users/abhimanyuyadav/Desktop/Photo/191234.jpg");
                 pstmt.setString(1, "Abhimanyu Yadav");
                 pstmt.setString(2, "House");
                 pstmt.setBlob(3, fis);
                 pstmt.setInt(4, 0);
                 pstmt.setString(5, "HEAD BOY");
                 pstmt.setByte(6, x);
               
                 pstmt.execute();
            }
            
            
        }
        catch(SQLException ex)
        {
            ex.printStackTrace();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(AdMain4JC.class.getName()).log(Level.SEVERE, null, ex);
        } 
    }
    
    public static void main(String args[])
    {
        test();
    }
    
}
