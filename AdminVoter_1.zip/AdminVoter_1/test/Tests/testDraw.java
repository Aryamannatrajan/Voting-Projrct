/*
 * Copyright (C) 2020 abhimanyuyadav
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
package Tests;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Objects;

/**
 *
 * @author abhimanyuyadav
 */
public class testDraw {

    static ArrayList<Integer> arcode = new ArrayList<>();
    static ArrayList<Integer> election = new ArrayList<>();
    static int pNo = 4;

    public static void main(String args[]) {
        try {
            System.out.println("HI");
            String urL = "jdbc:mysql://localhost:3306/TBS?zeroDateTimeBehavior=CONVERT_TO_NULL";
            String user = "root";
            String pass = "TBS@admin123";
            Connection conn = DriverManager.getConnection(urL, user, pass);
            Statement st = conn.createStatement();
            String q = "SELECT * FROM CANDIDATE ORDER BY VOTES DESC";
            ResultSet rs = st.executeQuery(q);
            ArrayList<Integer> vote = new ArrayList<>();
            ArrayList<Integer> code = new ArrayList<>();
            while (rs.next()) {
                String p = rs.getString("POSITION");
                if (p.equals("HEAD BOY")) {
                    vote.add(rs.getInt("VOTES"));
                    code.add(rs.getInt("CODE"));
                }
            }
            results(vote, code);
            for (int j = 0; j < election.size(); j++) {
                System.out.println(election.get(j));
            }

            for (int j = 0; j < arcode.size(); j++) {
                System.out.println(code.get(j) + "  selected");
            }
        } catch (SQLException ex) {

            ex.printStackTrace();
        }

    }

    private static void results(ArrayList<Integer> vote, ArrayList<Integer> code) {
        int v;
        for (int i = 0; i < vote.size(); i++) {

            if (arcode.size() < pNo) {
                arcode.add(code.get(i));
            } else {
                if (Objects.equals(vote.get(pNo - 1), vote.get(i))) {
                    v = vote.get(i);
                    selectElection(v, code, vote);
                } else {
                    break;
                }
            }

        }

    }

    private static void selectElection(int v, ArrayList<Integer> code, ArrayList<Integer> vote) {
        for (int i = 0; i < code.size(); i++) {
            if (vote.get(i) == v) {
                election.add(code.get(i));
                removeFromSelected(code.get(i));
            }
        }

    }

    private static void removeFromSelected(int code) {
        for (int i = 0; i < arcode.size(); i++) {
            if (code == arcode.get(i)) {
                arcode.remove(i);
            }
        }
    }

}

//                                                                                    System.out.println(rs.getString("NAME"));
//                                                                                    updateWinner(rs.getString("NAME"), rs.getString("HOUSE"), rs.getBlob("PHOTO"), rs.getInt("CODE"), part, conn);
//                                                                                    if (part.equalsIgnoreCase("HEAD BOY")) {
//                                                                                        updateCan("VICE HEAD BOY");
//                                                                                    } else if (part.equalsIgnoreCase("HEAD GIRL")) {
//                                                                                        updateCan("VICE HEAD GIRL");
//                                                                                    } else if (part.equalsIgnoreCase("VICE HEAD BOY") || part.equalsIgnoreCase("SPORTS CAPTAIN")) {
//                                                                                        updateCan(" HOUSE PREFECTS");
//                                                                                    }
